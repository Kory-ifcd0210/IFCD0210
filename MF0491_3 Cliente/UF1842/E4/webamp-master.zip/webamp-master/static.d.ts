declare module "*.wsz";
declare module "*.mp3";
declare module "*.png";
declare module "*.ico";
declare module "*.jpg";
declare module "*.svg";
