declare module "winamp-eqf" {
  import { parser, creator } from "winamp-eqf";
  export { parser, creator };
}
