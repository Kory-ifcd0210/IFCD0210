// Just a dummy service worker file. In the prod build, this would do something real.
