# Webamp.org

This directory contains the code used for [Webamp.org](https://webamp.org), as opposed to the `webamp` NPM module.
