module.exports = {
  displayName: "integration-test",
  rootDir: "../",
  preset: "jest-puppeteer",
  testRegex: "\\.integration-test\\.js$",
};
