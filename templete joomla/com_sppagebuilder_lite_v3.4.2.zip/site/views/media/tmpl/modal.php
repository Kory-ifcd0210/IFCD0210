<?php
defined('_JEXEC') or die();
require_once JPATH_ADMINISTRATOR . '/components/com_sppagebuilder/views/media/tmpl/modal.php';
