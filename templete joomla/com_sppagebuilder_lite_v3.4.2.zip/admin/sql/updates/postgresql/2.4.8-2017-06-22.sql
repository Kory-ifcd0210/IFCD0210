ALTER TABLE #__sppagebuilder ADD IF NOT EXISTS "asset_id" integer DEFAULT 0 NOT NULL;
