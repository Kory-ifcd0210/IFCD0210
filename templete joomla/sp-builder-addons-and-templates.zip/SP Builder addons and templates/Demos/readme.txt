you cannot install this files via extensions manager you need to install sp page builder, once page builder is installed you can import this pages in your live website 
