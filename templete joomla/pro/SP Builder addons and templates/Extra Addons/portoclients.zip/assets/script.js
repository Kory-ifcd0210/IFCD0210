
jQuery(function($){	


$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
	  items:6,

 
	  
	  });
});

});
